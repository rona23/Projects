
public interface Pet {
	public int getPet_id(); 
	
	public void setPet_id(int pet_id) ;
	
	public String getPet_name() ;

	public void setPet_name(String pet_name);
	
	public String getPet_type();	

	public void setPet_type(String pet_type);

	public boolean isPet_description();

	public void setPet_description(boolean pet_description) ;
	
	public String Display();
	
}
